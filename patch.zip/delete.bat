@echo off
del /f /q "%~dp0RanClient.exe.bak"